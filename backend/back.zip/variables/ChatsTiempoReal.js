export const Suscripcion_ChatAbierto = {}; // Objeto para almacenar las suscripciones de chat abierto
export const Timer_Expiracion_Chat = {};
export const TIEMPO_EXPIRACION_MS = 5000;
export const clientsMap = new Map();
export let clientesFirebase = new Map();
